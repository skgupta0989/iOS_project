//
//  main.m
//  restore
//
//  Created by Keith Harrison on 17/03/2013.
//  Copyright (c) 2013 Keith Harrison. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UYLAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([UYLAppDelegate class]));
    }
}
