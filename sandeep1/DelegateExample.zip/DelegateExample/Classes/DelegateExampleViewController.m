//
//  DelegateExampleViewController.m
//  DelegateExample
//
//  Created by Ryan Newsome on 4/11/11.
//

#import "DelegateExampleViewController.h"

@implementation DelegateExampleViewController

-(IBAction)changeAmountPressed
{
    EnterAmountViewController * enterAmountVC = [[EnterAmountViewController alloc]initWithNibName:@"EnterAmountViewController" bundle:nil];
    
    //important to set the viewcontroller's delegate to be self
    enterAmountVC.delegate = self;
    
    [self presentModalViewController:enterAmountVC animated:YES];
}


#pragma mark EnterNumbe Delegate function

//display the amount in the text field
-(void)amountEntered:(NSInteger)amount
{
    amountLabel.text = [NSString stringWithFormat:@"%i" , amount];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
