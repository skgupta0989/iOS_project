//
//  EnterAmountViewController.h
//  DelegateExample
//
//  Created by Ryan Newsome on 4/11/11.
//

#import <UIKit/UIKit.h>


//delegate to return amount entered by the user
@protocol EnterAmountDelegate <NSObject>

-(void)amountEntered:(NSInteger)amount;

@end


@interface EnterAmountViewController : UIViewController {

    IBOutlet UITextField *amountTextField;
    
    id<EnterAmountDelegate> delegate;
    
}

-(IBAction)cancelPressed;
-(IBAction)savePressed;

@property(nonatomic,assign)id delegate;

@end
