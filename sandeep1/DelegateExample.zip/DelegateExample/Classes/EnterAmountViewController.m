//
//  EnterAmountViewController.m
//  DelegateExample
//
//  Created by Ryan Newsome on 4/11/11.
//

#import "EnterAmountViewController.h"


@implementation EnterAmountViewController


@synthesize delegate;

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    
    amountTextField.text = @"";
    [amountTextField becomeFirstResponder];
    
}


-(IBAction)cancelPressed
{
    [self dismissModalViewControllerAnimated:YES];
}

-(IBAction)savePressed
{
    //Is anyone listening
    if([delegate respondsToSelector:@selector(amountEntered:)])
    {
        //send the delegate function with the amount entered by the user
        [delegate amountEntered:[amountTextField.text intValue]];
    }
    
    [self dismissModalViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
