//
//  DelegateExampleViewController.h
//  DelegateExample
//
//  Created by Ryan Newsome on 4/11/11.
//

#import <UIKit/UIKit.h>
#import "EnterAmountViewController.h"

@interface DelegateExampleViewController : UIViewController  <EnterAmountDelegate>{

    IBOutlet UILabel *amountLabel;
}

-(IBAction)changeAmountPressed;

@end

