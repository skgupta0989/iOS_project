//
//  DelegateExampleAppDelegate.h
//  DelegateExample
//
//  Created by Ryan Newsome on 4/11/11.
//

#import <UIKit/UIKit.h>

@class DelegateExampleViewController;

@interface DelegateExampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    DelegateExampleViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet DelegateExampleViewController *viewController;

@end

