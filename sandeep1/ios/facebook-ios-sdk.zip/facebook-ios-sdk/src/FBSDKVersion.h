// Note the versioning string has moved to the public FacebookSDK.h
#define FB_IOS_SDK_MIGRATION_BUNDLE @"fbsdk:20130912"

